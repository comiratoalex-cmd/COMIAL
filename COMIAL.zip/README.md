
# COMIAL - DBD Counter (Remote Bundle)

Este repositório publica `public/app.js` via GitHub Pages.
Substitua o conteúdo de `public/app.js` pelo arquivo completo fornecido na conversa.
